# AI Drone Box: code for the 2 AI models

This is the Python code for the two algorithms in the doc *AI Drone Box: Algorithms for the 2 AI Models*.
It includes a building simulator, so you can run and test the full mission on a laptop before any hardware exists.

## Quick start

```bash
pip install -r requirements.txt        # numpy, scipy, scikit-learn, matplotlib are enough for the demo
python train_detector.py               # trains Model 2's detector classifier, prints macro-F1 + confusion matrix
python demo.py --all                   # runs 5 incidents end to end, saves maps to output/
```

If PyTorch is installed, `train_detector.py` trains the 1D-CNN that goes on the detectors and exports it to ONNX.
Without PyTorch, it trains a small scikit-learn model instead, so the demo still runs.

## Project layout

```
common/building.py              building simulator: floor plan, furniture, detectors, fire/gas physics
model1_navigation/              MODEL 1: drone dodging obstacles, mapping, building structure
    mapping.py                  occupancy grid built from LiDAR scans, starting from the floor plan
    semantic_graph.py           rooms + doors graph, room hazards, survivors, search order
    planner.py                  A* global planner (heat/smoke cost) + VFH local obstacle avoidance
    perception.py               YOLO wrapper (real drone) + simulated camera, RGB+thermal fusion
    navigator.py                the control loop: sense -> map -> perceive -> re-plan -> avoid -> move
model2_detection/               MODEL 2: roof detectors + drone detectors
    preprocess.py               filtering, normalisation, features, HARD alarm thresholds (no AI)
    detector_model.py           1D-CNN (PyTorch) + sklearn fallback, synthetic training data
    fusion.py                   source location, gas composition, risk score, drone update, fire level 0-4, decision
mission.py                      the AI box: main loop tying both models together
demo.py                         5 scenarios: small_fire, survivor, big_fire, gas_leak, false_alarm
train_detector.py               train + evaluate Model 2's detector (workshop criteria)
train_yolo.py, data/            train the drone's YOLOv8n with transfer learning, export to TensorRT INT8
```

## What the demo shows

| Scenario | What happens |
| --- | --- |
| small_fire | Detector in R7 spots the fire, the drone flies there, sees a level-2 fire, drops 1 CO2 bomb, the fire goes out |
| survivor | Fire in a ward with a person inside: the drone finds the person, so no CO2 is used; level 4, firefighters called, evacuation |
| big_fire | Fast-growing fire hidden behind furniture: the drone searches the room, finds it, level 3, firefighters called |
| gas_leak | CH4 leak: cut gas and power, ventilate, never use CO2 (ignition risk); cleared once the gas is gone |
| false_alarm | Steam in the kitchen: classified as nuisance, no drone sent |

## Moving from the simulator to the real system

| Simulator piece | Replace with |
| --- | --- |
| `simulate_lidar`, pose from the simulator | Real LiDAR / depth camera + a SLAM package (ORB-SLAM3, Cartographer or RTAB-Map on ROS 2), feeding `OccupancyGrid.update_scan` |
| `SimPerception` | `YoloPerception` with the weights from `train_yolo.py`, on the Jetson |
| `sensor_sample` synthetic data | Real recordings from your detectors: lab gas tests, smoke tests, nuisance sources (steam, cooking) |
| `drone.pose += step` | Commands to the flight controller (PX4 / ArduPilot via MAVROS); test first in Gazebo + PX4 SITL |
| `call_firefighters`, `alarm`, `cut_gas` (logs only) | The building's certified fire-alarm panel and emergency-call interface |

## Important limits

- **The training data is synthetic.** The near-perfect macro-F1 here only shows that the pipeline works. Real sensors drift and react to many gases at once, so the real score will be lower until you train on real recordings.
- **Every threshold marked `CALIBRATE`** (fire levels, risk score, gas limits) is a starting value. Tune them with real burn tests and have a fire-safety engineer validate them.
- **Safety rules the code enforces:** no CO2 in a room where people are detected (CO2 pushes out oxygen); never put out a gas fire while gas is still flowing; hard alarms work even if the AI fails; firefighters are called if the drone cannot find a fire that the sensors report.
