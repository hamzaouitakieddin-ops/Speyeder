"""
Run a full simulated incident: detectors -> AI box -> drone -> decision.

    python demo.py --scenario small_fire     # CO2 drone puts it out
    python demo.py --scenario survivor       # person in the fire room: no CO2, call firefighters
    python demo.py --scenario big_fire       # fast fire: firefighters + drone scouts
    python demo.py --scenario gas_leak       # leak: cut gas, ventilate, no CO2 (ignition risk)
    python demo.py --scenario false_alarm    # steam in the kitchen: no dispatch
    python demo.py --all                     # run them all and print a summary table

Saves a map of each mission to output/<scenario>.png
"""
import argparse
import os

import numpy as np

from common.building import Event, make_building
from mission import AIBox
from model2_detection.detector_model import DetectorClassifier, make_dataset

SCENARIOS = {
    #  name        : (kind,        room cell, start, growth/s, co2 factor, people, expected occupancy)
    "small_fire":  ("flaming",    (40, 34), 0.05, 0.002, 1.0, [], {}),
    "survivor":    ("flaming",    (10, 34), 0.05, 0.002, 0.5, [(5, 30)], {"R5 Ward A": 1}),
    "big_fire":    ("flaming",    (42, 5), 0.10, 0.012, 1.0, [], {}),
    "gas_leak":    ("gas_leak",   (58, 34), 0.10, 0.003, 0.0, [], {}),
    "false_alarm": ("nuisance",   (42, 5), 0.30, 0.004, 0.0, [], {}),
}


def get_classifier():
    clf = DetectorClassifier()
    path = "weights/gas_detector." + ("pt" if clf.backend == "torch" else "pkl")
    if os.path.exists(path):
        return clf.load(path)
    print("No trained detector found - training a quick one (run train_detector.py for the full version)")
    X, y = make_dataset(300, seed=1)
    return clf.fit(X, y, X[::5], y[::5])


def run(name, clf, plot=True, verbose=True):
    kind, pos, start, growth, co2f, people, occ = SCENARIOS[name]
    b = make_building(seed=0)
    b.true_grid[pos[1], pos[0]] = 0
    b.people = people
    ev = Event(kind, pos, intensity=start, growth=growth, co2_factor=co2f)
    box = AIBox(b, clf, ev, occupancy=occ, seed=1, verbose=verbose)
    if verbose:
        print(f"\n================  SCENARIO: {name}  ================")
    res = box.run()
    if plot:
        save_plot(name, b, box, ev)
    return res


def save_plot(name, b, box, ev):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    os.makedirs("output", exist_ok=True)
    fig, ax = plt.subplots(1, 2, figsize=(14, 5))
    ax[0].imshow(b.true_grid, cmap="Greys", origin="upper")
    ax[0].set_title("Real building (walls + furniture)")
    p = box.drone.map.prob()
    shown = np.where(box.drone.map.seen, p, 0.5)
    ax[1].imshow(shown, cmap="Greys", origin="upper", vmin=0, vmax=1)
    ax[1].set_title("Drone's map after the mission (grey = never seen)")
    for a in ax:
        tr = np.array(box.drone.trail)
        a.plot(tr[:, 0], tr[:, 1], "-", color="tab:blue", lw=1.5, label="drone path")
        for d in b.detectors:
            a.plot(*d.pos, "s", color="tab:green", ms=5)
        a.plot(*ev.pos, "*", color="tab:red", ms=16, label=f"{ev.kind} source")
        for pp in b.people:
            a.plot(*pp, "o", color="tab:orange", ms=9, label="trapped person")
        a.plot(*b.dock, "^", color="tab:purple", ms=10, label="drone dock")
        for r in b.rooms:
            a.text(r.x0 + 1, r.y0 + 1.5, r.name, fontsize=7, color="tab:gray")
        a.set_xticks([]); a.set_yticks([])
    h, l = ax[0].get_legend_handles_labels()
    fig.legend(h, l, loc="lower center", ncol=5, fontsize=8)
    res = box.summary()
    fig.suptitle(f"{name}: level {res['level']}, firefighters called={res['firefighters_called']}, "
                 f"extinguished={res['extinguished']}, CO2 used={res['co2_used']}")
    fig.tight_layout(rect=(0, 0.06, 1, 0.95))
    fig.savefig(f"output/{name}.png", dpi=110)
    plt.close(fig)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--scenario", choices=list(SCENARIOS), default="small_fire")
    ap.add_argument("--all", action="store_true")
    args = ap.parse_args()
    clf = get_classifier()
    names = list(SCENARIOS) if args.all else [args.scenario]
    results = {n: run(n, clf) for n in names}
    if args.all:
        print("\n=== SUMMARY ===")
        for n, r in results.items():
            print(f"{n:12s} {r}")


if __name__ == "__main__":
    main()
