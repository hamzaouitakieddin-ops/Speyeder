"""
Model 1 - part 5: perception (what the drone's cameras see).

YoloPerception  : the real model. YOLOv8n fine-tuned on your classes
                  (person, fire, smoke, door, stairs, debris), fed with an
                  RGB + thermal fused image so it still works in smoke.
                  Needs:  pip install ultralytics  (and a trained weights file).
SimPerception   : stand-in used by the simulator. Same output format, so the
                  navigator code does not change when you switch to the real one.

Detection format (both):
    {"cls": "person"|"fire"|"smoke"|..., "conf": float, "pos": (x, y) cell,
     "room": str, "severity": 0..1 (fire only)}
"""
from __future__ import annotations

import math

import numpy as np

from common.building import CELL_M, line_of_sight

CLASSES = ["person", "fire", "smoke", "door", "stairs", "debris"]


def fuse_rgb_thermal(rgb: np.ndarray, thermal: np.ndarray, alpha=0.5) -> np.ndarray:
    """Blend a normalised thermal image into the RGB frame (same H x W).
    Smoke hides objects in RGB but not in thermal: the fused image keeps both."""
    t = thermal.astype(np.float32)
    t = (t - t.min()) / (t.max() - t.min() + 1e-6) * 255.0
    t3 = np.repeat(t[..., None], 3, axis=2)
    return ((1 - alpha) * rgb.astype(np.float32) + alpha * t3).clip(0, 255).astype(np.uint8)


class YoloPerception:
    """Real detector for the Jetson. Export to TensorRT for speed:
        YOLO('best.pt').export(format='engine', int8=True)"""

    def __init__(self, weights="weights/fire_drone_yolov8n.pt", conf=0.35):
        from ultralytics import YOLO          # imported here so the simulator runs without it
        self.model = YOLO(weights)
        self.conf = conf

    def detect(self, rgb, thermal=None, pose=None, depth=None, room="?"):
        img = fuse_rgb_thermal(rgb, thermal) if thermal is not None else rgb
        res = self.model.predict(img, conf=self.conf, verbose=False)[0]
        out = []
        for box in res.boxes:
            cls = res.names[int(box.cls)]
            x1, y1, x2, y2 = box.xyxy[0].tolist()
            det = {"cls": cls, "conf": float(box.conf), "bbox": (x1, y1, x2, y2), "room": room}
            if depth is not None and pose is not None:
                # project the box centre to a map cell using the depth image
                u, v = int((x1 + x2) / 2), int((y1 + y2) / 2)
                z_m = float(depth[v, u])
                fx = img.shape[1] / 2 / math.tan(math.radians(43))     # ~86 deg HFOV camera
                bearing = pose[2] + math.atan2(u - img.shape[1] / 2, fx)
                det["pos"] = (pose[0] + z_m / CELL_M * math.cos(bearing),
                              pose[1] + z_m / CELL_M * math.sin(bearing))
            if cls == "fire":
                det["severity"] = min(1.0, (x2 - x1) * (y2 - y1) / (img.shape[0] * img.shape[1]) * 4)
            out.append(det)
        return out


class SimPerception:
    """Simulated thermal + RGB detector: sees fire up to 10 m and people up to 8 m with line of sight."""

    def __init__(self, building, fire_range_m=10.0, person_range_m=8.0, miss_rate=0.1, seed=0):
        self.b = building
        self.fire_r = fire_range_m / CELL_M
        self.person_r = person_range_m / CELL_M
        self.miss = miss_rate
        self.rng = np.random.default_rng(seed)

    def detect(self, pose_xy, event=None):
        out = []
        g = self.b.true_grid
        visible_kinds = ("flaming", "smouldering")            # a gas leak is invisible to cameras
        if event is not None and event.kind in visible_kinds and not event.extinguished and event.intensity > 0.02:
            d = math.dist(pose_xy, event.pos)
            if d < self.fire_r and line_of_sight(g, pose_xy, event.pos):
                cls = "fire" if event.kind == "flaming" else "smoke"
                out.append({"cls": cls, "conf": 0.9, "pos": event.pos,
                            "room": self.b.room_at(*event.pos), "severity": event.intensity})
        for p in self.b.people:
            d = math.dist(pose_xy, p)
            if d < self.person_r and line_of_sight(g, pose_xy, p) and self.rng.random() > self.miss:
                out.append({"cls": "person", "conf": 0.85, "pos": p, "room": self.b.room_at(*p)})
        return out
