"""
Model 1 - parts 3 & 4: global path planning + local obstacle avoidance.

GlobalPlanner : A* on the occupancy grid, 8-connected, with a hazard cost
                map (heat / smoke). Re-planning is done whenever the map or
                the hazards change (a simple, robust stand-in for D* Lite).
VFHAvoider    : Vector Field Histogram on the raw LiDAR ranges. It runs every
                control step and bends the planned direction away from
                obstacles the map has not caught yet (people moving, falling
                debris).
"""
from __future__ import annotations

import heapq
import math

import numpy as np
from scipy.ndimage import binary_dilation

SQRT2 = math.sqrt(2)
MOVES = [(1, 0, 1), (-1, 0, 1), (0, 1, 1), (0, -1, 1),
         (1, 1, SQRT2), (1, -1, SQRT2), (-1, 1, SQRT2), (-1, -1, SQRT2)]


class GlobalPlanner:
    def __init__(self, inflate_cells=1, unknown_cost=0.3):
        self.inflate = inflate_cells
        self.unknown_cost = unknown_cost

    def plan(self, obstacles, start, goal, hazard=None, seen=None):
        """A*: returns a list of cells from start to goal, or None."""
        h, w = obstacles.shape
        blocked = obstacles.astype(bool)
        if self.inflate:
            blocked = binary_dilation(blocked, iterations=self.inflate)
        start = (int(round(start[0])), int(round(start[1])))
        goal = (int(round(goal[0])), int(round(goal[1])))
        blocked[start[1], start[0]] = False           # never trap the drone in its own cell
        blocked[goal[1], goal[0]] = obstacles[goal[1], goal[0]] == 1

        extra = np.zeros((h, w), dtype=np.float32)
        if hazard is not None:
            extra += 6.0 * hazard                     # heat / smoke makes a cell expensive
        if seen is not None:
            extra += np.where(seen, 0.0, self.unknown_cost)   # prefer known space

        def heur(c):
            dx, dy = abs(c[0] - goal[0]), abs(c[1] - goal[1])
            return (dx + dy) + (SQRT2 - 2) * min(dx, dy)

        g = {start: 0.0}
        prev = {}
        pq = [(heur(start), start)]
        while pq:
            _, cur = heapq.heappop(pq)
            if cur == goal:
                path = [cur]
                while cur in prev:
                    cur = prev[cur]
                    path.append(cur)
                return path[::-1]
            cx, cy = cur
            for dx, dy, step in MOVES:
                nx, ny = cx + dx, cy + dy
                if not (0 <= nx < w and 0 <= ny < h) or blocked[ny, nx]:
                    continue
                if dx and dy and (blocked[cy, nx] or blocked[ny, cx]):
                    continue                          # no cutting corners
                ng = g[cur] + step * (1.0 + extra[ny, nx])
                if ng < g.get((nx, ny), math.inf):
                    g[(nx, ny)] = ng
                    prev[(nx, ny)] = cur
                    heapq.heappush(pq, (ng + heur((nx, ny)), (nx, ny)))
        return None


class VFHAvoider:
    """Pick the free direction closest to the desired one."""

    def __init__(self, safety_cells=1.5, sectors=72, smooth=2):
        self.safety = safety_cells
        self.sectors = sectors
        self.smooth = smooth

    def steer(self, desired_heading, angles, ranges, step=1.0):
        free = ranges > (self.safety + step)
        # widen blocked sectors so the drone keeps clearance on both sides
        blocked = ~free
        widened = blocked.copy()
        for k in range(1, self.smooth + 1):
            widened |= np.roll(blocked, k) | np.roll(blocked, -k)
        candidates = np.where(~widened)[0]
        if len(candidates) == 0:
            return None                               # boxed in: hover and re-plan
        diff = np.abs(np.angle(np.exp(1j * (angles[candidates] - desired_heading))))
        best = candidates[np.argmin(diff)]
        if diff.min() < math.radians(5):
            return desired_heading                    # path is clear, keep the plan
        return float(angles[best])
