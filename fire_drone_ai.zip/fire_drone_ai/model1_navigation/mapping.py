"""
Model 1 - part 1: mapping (the "M" of SLAM).

OccupancyGrid keeps a log-odds value per cell:
    > 0  -> probably an obstacle,  < 0 -> probably free,  0 -> unknown.
It starts from the architect's floor plan (walls) and is updated with every
LiDAR / depth scan, so furniture, debris and blocked doors appear as the
drone flies.

Localization: in this simulator the pose comes from the flight controller
(visual-inertial odometry). On the real drone, run a SLAM package
(ORB-SLAM3, Cartographer or RTAB-Map under ROS 2) to get the pose, and feed
its scans into this same grid.
"""
from __future__ import annotations

import math

import numpy as np

L_OCC, L_FREE = 0.85, -0.4       # log-odds increments for a hit / a pass-through
L_MIN, L_MAX = -4.0, 4.0
L_PRIOR_WALL = 3.0               # floor-plan walls start almost certain


class OccupancyGrid:
    def __init__(self, prior_walls: np.ndarray):
        self.logodds = np.where(prior_walls == 1, L_PRIOR_WALL, 0.0).astype(np.float32)
        self.seen = prior_walls.astype(bool).copy()
        self.h, self.w = prior_walls.shape

    def prob(self):
        return 1.0 / (1.0 + np.exp(-self.logodds))

    def obstacles(self, threshold=0.65) -> np.ndarray:
        return (self.prob() > threshold).astype(np.int8)

    def update_scan(self, pose_xy, angles, ranges, max_range):
        """Bresenham-free ray update: walk each beam in small steps."""
        px, py = pose_xy
        for a, r in zip(angles, ranges):
            hit = r < max_range
            n = int(r / 0.5) + 1
            last = None
            for k in range(n):
                d = k * 0.5
                cx, cy = int(round(px + d * math.cos(a))), int(round(py + d * math.sin(a)))
                if not (0 <= cx < self.w and 0 <= cy < self.h) or (cx, cy) == last:
                    continue
                last = (cx, cy)
                self.logodds[cy, cx] = max(L_MIN, self.logodds[cy, cx] + L_FREE)
                self.seen[cy, cx] = True
            if hit:
                hx, hy = int(round(px + r * math.cos(a))), int(round(py + r * math.sin(a)))
                if 0 <= hx < self.w and 0 <= hy < self.h:
                    self.logodds[hy, hx] = min(L_MAX, self.logodds[hy, hx] + L_OCC + abs(L_FREE))
                    self.seen[hy, hx] = True


def simulate_lidar(true_grid, pose_xy, n_beams=72, max_range=16.0):
    """360-degree LiDAR on the simulated building. Range is in cells (16 cells = 8 m)."""
    angles = np.linspace(-math.pi, math.pi, n_beams, endpoint=False)
    ranges = np.full(n_beams, max_range)
    h, w = true_grid.shape
    px, py = pose_xy
    for i, a in enumerate(angles):
        d = 0.0
        while d < max_range:
            d += 0.25
            cx, cy = int(round(px + d * math.cos(a))), int(round(py + d * math.sin(a)))
            if not (0 <= cx < w and 0 <= cy < h) or true_grid[cy, cx] == 1:
                ranges[i] = d
                break
    return angles, ranges
