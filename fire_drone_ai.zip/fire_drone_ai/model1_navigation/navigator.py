"""
Model 1 - the navigation loop (Algorithm "DroneNavigation" in the doc).

Every control step (0.5 s in the simulator, 20 Hz on the real drone):
    sense (LiDAR + cameras) -> update map -> perceive (YOLO) ->
    update semantic graph -> re-plan if needed -> avoid obstacles -> move
"""
from __future__ import annotations

import math

import numpy as np

from common.building import CELL_M, line_of_sight
from model1_navigation.mapping import OccupancyGrid, simulate_lidar
from model1_navigation.planner import GlobalPlanner, VFHAvoider
from model1_navigation.semantic_graph import SemanticGraph

MAX_RANGE = 16.0      # LiDAR range in cells (8 m)


class DroneNavigator:
    def __init__(self, building, perception, drone_id="DRONE-1", battery=1.0, co2_bombs=3, log=print):
        self.b = building
        self.id = drone_id
        self.pose = np.array(building.dock, dtype=float)
        self.heading = 0.0
        self.map = OccupancyGrid(building.prior_grid)          # starts from the floor plan
        self.graph = SemanticGraph(building)
        self.hazard = np.zeros_like(building.prior_grid, dtype=np.float32)
        self.planner = GlobalPlanner(inflate_cells=1)
        self.avoider = VFHAvoider()
        self.perception = perception
        self.battery = battery
        self.co2_bombs = co2_bombs
        self.path, self.trail = [], [tuple(self.pose)]
        self.detections_log = []
        self.log = log
        self.steps_since_plan = 0

    # ---------------- helpers ----------------
    @property
    def room(self):
        return self.b.room_at(*self.pose)

    def _mark_fire_hazard(self, det):
        """Cells around a seen fire get a high cost so the drone keeps its distance."""
        radius = 3.0 + 6.0 * det.get("severity", 0.5)            # cells
        yy, xx = np.mgrid[0:self.hazard.shape[0], 0:self.hazard.shape[1]]
        d = np.hypot(xx - det["pos"][0], yy - det["pos"][1])
        self.hazard = np.maximum(self.hazard, np.clip(1.0 - d / radius, 0, 1))

    def _path_blocked(self, lookahead=8):
        obst = self.map.obstacles()
        return any(obst[c[1], c[0]] for c in self.path[:lookahead])

    def _replan(self, goal):
        obst = self.map.obstacles()
        if obst[int(round(goal[1])), int(round(goal[0]))]:
            goal = self.nearest_free(goal)                     # target turned out to be under furniture
        self.path = self.planner.plan(self.map.obstacles(), self.pose, goal, self.hazard, self.map.seen) or []
        self.steps_since_plan = 0

    # ---------------- one control step ----------------
    def step(self, goal, event=None, dt=0.5, speed_cells=1.0):
        # 1. sense + map
        angles, ranges = simulate_lidar(self.b.true_grid, self.pose, max_range=MAX_RANGE)
        self.map.update_scan(self.pose, angles, ranges, MAX_RANGE)

        # 2. perceive + update the building model
        dets = self.perception.detect(tuple(self.pose), event)
        for d in dets:
            if d["cls"] in ("fire", "smoke"):
                self._mark_fire_hazard(d)
        self.graph.update_from_detections(self.room, dets, tuple(self.pose))
        self.detections_log.extend(dets)

        # 3. re-plan when needed (new obstacle on the path, every 10 steps, or no path)
        if not self.path or self._path_blocked() or self.steps_since_plan >= 10:
            self._replan(goal)
        self.steps_since_plan += 1
        if not self.path:
            return dets, "NO_PATH"

        # 4. follow the path: aim at a point a few cells ahead
        while len(self.path) > 1 and math.dist(self.path[0], self.pose) < 0.8:
            self.path.pop(0)
        target = self.path[min(2, len(self.path) - 1)]
        desired = math.atan2(target[1] - self.pose[1], target[0] - self.pose[0])

        # 5. local avoidance (VFH) on the raw scan
        heading = self.avoider.steer(desired, angles, ranges, step=speed_cells)
        if heading is None:
            self.path = []
            return dets, "BLOCKED"
        step = min(speed_cells, math.dist(target, self.pose))
        new = self.pose + step * np.array([math.cos(heading), math.sin(heading)])
        if self.b.free(*new):                                      # physical safety check
            self.pose = new
            self.heading = heading
        else:
            self.path = []                                         # force re-plan next step
        self.trail.append(tuple(self.pose))
        self.battery -= 0.0015 * dt / 0.5
        return dets, "MOVING"

    def go_to(self, goal, event=None, stop_dist=1.0, need_los=False, max_steps=400, on_step=None):
        """Fly until within stop_dist cells of goal (and in line of sight if asked)."""
        self.path = []
        for _ in range(max_steps):
            d = math.dist(self.pose, goal)
            if d <= stop_dist and (not need_los or line_of_sight(self.b.true_grid, self.pose, goal)):
                return "ARRIVED"
            if self.battery < 0.25:
                return "LOW_BATTERY"
            dets, status = self.step(goal, event)
            if on_step and on_step(self, dets):
                return "STOPPED"                           # the mission manager asked to stop early
            if status == "NO_PATH":
                self.log(f"[{self.id}] no path to {goal} - door blocked? asking box for another target")
                return "NO_PATH"
        return "TIMEOUT"

    def nearest_free(self, cell, max_r=6):
        """Closest cell to `cell` that is free in the drone's map (room centres can be under furniture)."""
        obst = self.map.obstacles()
        cx, cy = int(round(cell[0])), int(round(cell[1]))
        for r in range(max_r + 1):
            for dx in range(-r, r + 1):
                for dy in range(-r, r + 1):
                    x, y = cx + dx, cy + dy
                    if max(abs(dx), abs(dy)) == r and 0 < x < obst.shape[1] - 1 and 0 < y < obst.shape[0] - 1 \
                            and not obst[y, x] and self.b.room_at(x, y) == self.b.room_at(cx, cy):
                        return (x, y)
        return (cx, cy)

    def standoff_point(self, source, dist_m=2.5):
        """Free, known cell about dist_m from the fire, with line of sight, closest to the drone."""
        best, best_d = None, math.inf
        r = dist_m / CELL_M
        obst = self.map.obstacles()
        for k in range(48):
            a = 2 * math.pi * k / 48
            c = (int(round(source[0] + r * math.cos(a))), int(round(source[1] + r * math.sin(a))))
            if not (0 < c[0] < obst.shape[1] - 1 and 0 < c[1] < obst.shape[0] - 1):
                continue
            if obst[c[1], c[0]] or not line_of_sight(obst, c, source):
                continue
            d = math.dist(c, self.pose)
            if d < best_d:
                best, best_d = c, d
        return best or (int(source[0]), int(source[1]))
