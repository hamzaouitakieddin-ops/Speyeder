"""
Model 1 - part 2: understanding the building structure.

A semantic graph on top of the grid map:
    nodes = rooms / corridor (with tags: patients, electrical, chemicals...)
    edges = doors, with a cost (distance + heat + smoke + blocked)
The drone and the AI box use it to reason in rooms ("fire in R7 Storage,
survivor in R8 Lab, door R7->corridor blocked") instead of raw coordinates,
and to pick which rooms to search for survivors.
"""
from __future__ import annotations

import heapq
import math


class SemanticGraph:
    def __init__(self, building):
        self.rooms = {r.name: r for r in building.rooms}
        self.edges = {}                       # (a, b) -> dict(door=cell, cost=..., blocked=bool)
        for cell, a, b in building.doors:
            d = math.dist(self.rooms[a].center, self.rooms[b].center)
            self.edges[(a, b)] = self.edges[(b, a)] = {"door": cell, "base": d, "hazard": 0.0, "blocked": False}
        self.room_state = {n: {"hazard": 0.0, "occupied": False, "survivors": [], "visited": False}
                           for n in self.rooms}

    def neighbours(self, room):
        return [b for (a, b) in self.edges if a == room]

    def edge_cost(self, a, b):
        e = self.edges[(a, b)]
        if e["blocked"]:
            return math.inf
        return e["base"] * (1.0 + 4.0 * e["hazard"] + 2.0 * self.room_state[b]["hazard"])

    def update_from_detections(self, room, detections, pose):
        """Called by the navigator after each perception step."""
        if room not in self.room_state:
            return
        st = self.room_state[room]
        st["visited"] = True
        for det in detections:
            if det["cls"] == "person":
                st["occupied"] = True
                if all(math.dist(det["pos"], p) > 2 for p in st["survivors"]):
                    st["survivors"].append(det["pos"])
            elif det["cls"] in ("fire", "smoke"):
                fire_room = det.get("room", room)
                self.room_state[fire_room]["hazard"] = max(self.room_state[fire_room]["hazard"],
                                                           det.get("severity", 0.5))

    def set_door_blocked(self, a, b, blocked=True):
        if (a, b) in self.edges:
            self.edges[(a, b)]["blocked"] = self.edges[(b, a)]["blocked"] = blocked

    def route(self, start_room, goal_room):
        """Dijkstra over rooms -> list of rooms to cross."""
        dist, prev = {start_room: 0.0}, {}
        pq = [(0.0, start_room)]
        while pq:
            d, u = heapq.heappop(pq)
            if u == goal_room:
                break
            if d > dist.get(u, math.inf):
                continue
            for v in self.neighbours(u):
                nd = d + self.edge_cost(u, v)
                if nd < dist.get(v, math.inf):
                    dist[v], prev[v] = nd, u
                    heapq.heappush(pq, (nd, v))
        if goal_room not in dist:
            return None
        path, n = [goal_room], goal_room
        while n != start_room:
            n = prev[n]
            path.append(n)
        return path[::-1]

    def search_order(self, fire_room, max_hops=2):
        """Rooms to sweep for survivors: fire room first, then by graph hops and distance; patient rooms first on ties."""
        fc = self.rooms[fire_room].center
        order, frontier, seen = [], [fire_room], {fire_room}
        for _ in range(max_hops + 1):
            nxt = []
            ranked = sorted(frontier, key=lambda r: (round(math.dist(self.rooms[r].center, fc) / 10),
                                                     "patients" not in self.rooms[r].tags))
            order.extend(ranked)
            for r in frontier:
                for n in self.neighbours(r):
                    if n not in seen:
                        seen.add(n)
                        nxt.append(n)
            frontier = nxt
        return [r for r in order if r != "Corridor"]
