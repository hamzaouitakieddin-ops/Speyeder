"""
Building simulator used to test both AI models without real hardware.

- A 2D grid floor plan (1 cell = 0.5 m): walls, doors, rooms, corridor.
- "prior" map  = what the AI box knows from the architect's floor plan (walls only).
- "true" map   = the real building (walls + furniture + debris the drone must discover).
- Fixed detectors in every room + corridor.
- A fire / gas-leak event with simple growth and spread physics.

On the real system this file is replaced by the real building, the real
sensors and the real drone. The models only see sensor readings, so the
same model code runs in both cases.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field

import numpy as np

CELL_M = 0.5            # metres per grid cell
W, H = 64, 40           # grid size in cells (32 m x 20 m)


@dataclass
class Room:
    name: str
    x0: int
    y0: int
    x1: int
    y1: int
    tags: tuple = ()     # e.g. ("electrical",), ("chemicals",), ("patients",)

    @property
    def center(self):
        return ((self.x0 + self.x1) // 2, (self.y0 + self.y1) // 2)

    def contains(self, x, y):
        return self.x0 <= x <= self.x1 and self.y0 <= y <= self.y1


@dataclass
class Detector:
    det_id: str
    pos: tuple
    room: str


@dataclass
class Event:
    """A fire or gas leak in the building (ground truth, hidden from the AI)."""
    kind: str                 # "flaming" | "smouldering" | "gas_leak" | "nuisance"
    pos: tuple                # source cell (x, y)
    intensity: float = 0.05   # 0..1
    growth: float = 0.004     # intensity added per second
    co2_factor: float = 1.0   # how well CO2 works on it (1 = good, 0.5 = class A solids)
    extinguished: bool = False

    def step(self, dt):
        if self.extinguished:
            return
        self.intensity = float(min(1.0, self.intensity + self.growth * dt))

    def hit_with_co2(self, shots=1):
        """One CO2 bomb knocks the fire down; a weak fire goes out."""
        for _ in range(shots):
            self.intensity -= 0.35 * self.co2_factor
        if self.intensity <= 0.05:
            self.intensity = 0.0
            self.extinguished = True

    # what a thermal camera would measure
    @property
    def hot_area_m2(self):
        return 0.0 if self.kind != "flaming" else 0.3 + 30.0 * self.intensity ** 2

    @property
    def t_max_c(self):
        if self.kind == "flaming":
            return 25 + 650 * self.intensity
        if self.kind == "smouldering":
            return 25 + 150 * self.intensity
        return 25.0


@dataclass
class Building:
    true_grid: np.ndarray            # 1 = obstacle, 0 = free   (real building)
    prior_grid: np.ndarray           # 1 = wall from floor plan  (what the box knows)
    rooms: list
    doors: list                      # list of (cell, roomA, roomB)
    detectors: list
    dock: tuple
    people: list = field(default_factory=list)   # trapped people (ground truth)

    def room_at(self, x, y) -> str:
        x, y = int(round(x)), int(round(y))
        for r in self.rooms:
            if r.contains(x, y):
                return r.name
        for cell, a, b in self.doors:            # standing in a doorway counts as the corridor
            if abs(cell[0] - x) <= 1 and cell[1] == y:
                return b
        return "Wall"

    def room(self, name) -> Room:
        return next(r for r in self.rooms if r.name == name)

    def free(self, x, y) -> bool:
        x, y = int(round(x)), int(round(y))
        return 0 <= x < W and 0 <= y < H and self.true_grid[y, x] == 0


def line_of_sight(grid, a, b) -> bool:
    """Bresenham line: True if no obstacle between cells a and b."""
    x0, y0 = int(round(a[0])), int(round(a[1]))
    x1, y1 = int(round(b[0])), int(round(b[1]))
    dx, dy = abs(x1 - x0), -abs(y1 - y0)
    sx, sy = (1 if x0 < x1 else -1), (1 if y0 < y1 else -1)
    err = dx + dy
    while (x0, y0) != (x1, y1):
        if grid[y0, x0] == 1:
            return False
        e2 = 2 * err
        if e2 >= dy:
            err += dy
            x0 += sx
        if e2 <= dx:
            err += dx
            y0 += sy
    return True


def make_building(seed: int = 0) -> Building:
    """8 rooms (4 top, 4 bottom) around a central corridor, like a hospital wing."""
    rng = np.random.default_rng(seed)
    g = np.zeros((H, W), dtype=np.int8)
    g[0, :] = g[-1, :] = 1
    g[:, 0] = g[:, -1] = 1
    g[16, :] = 1                      # wall between top rooms and corridor
    g[23, :] = 1                      # wall between corridor and bottom rooms
    for x in (16, 32, 48):            # walls between rooms
        g[0:17, x] = 1
        g[23:40, x] = 1

    names_top = [("R1 Lobby", ()), ("R2 Office", ()), ("R3 Kitchen", ("cooking",)),
                 ("R4 Server room", ("electrical",))]
    names_bot = [("R5 Ward A", ("patients",)), ("R6 Ward B", ("patients",)),
                 ("R7 Storage", ("chemicals",)), ("R8 Lab", ("chemicals",))]
    xs = [(1, 15), (17, 31), (33, 47), (49, 62)]
    rooms, doors = [], []
    for (name, tags), (x0, x1) in zip(names_top, xs):
        rooms.append(Room(name, x0, 1, x1, 15, tags))
    for (name, tags), (x0, x1) in zip(names_bot, xs):
        rooms.append(Room(name, x0, 24, x1, 38, tags))
    rooms.append(Room("Corridor", 1, 17, 62, 22))

    # 3-cell doors from each room to the corridor
    for r in rooms[:8]:
        cx = r.center[0] + 3
        wall_y = 16 if r.y0 == 1 else 23
        g[wall_y, cx - 1:cx + 2] = 0
        doors.append(((cx, wall_y), r.name, "Corridor"))

    prior = g.copy()                  # floor plan = walls only

    # furniture + debris: present in the real building, NOT in the floor plan
    true = g.copy()
    for r in rooms[:8]:
        for _ in range(3):
            bx = int(rng.integers(r.x0 + 2, r.x1 - 4))
            by = int(rng.integers(r.y0 + 2, r.y1 - 4))
            true[by:by + 2, bx:bx + 3] = 1
    true[18:20, 30] = 1               # a trolley left in the corridor
    true[17:19, 44] = 1               # fallen cabinet in the corridor
    for d, _, _ in doors:             # never block doors with furniture
        true[d[1] - 1:d[1] + 2, d[0] - 1:d[0] + 2] = prior[d[1] - 1:d[1] + 2, d[0] - 1:d[0] + 2]

    detectors = []
    for r in rooms[:8]:
        cx, cy = r.center
        while true[cy, cx] == 1:
            cx += 1
        detectors.append(Detector(f"D-{r.name.split()[0]}", (cx, cy), r.name))
    for i, x in enumerate((10, 32, 54)):
        detectors.append(Detector(f"D-C{i + 1}", (x, 19), "Corridor"))

    return Building(true, prior, rooms, doors, detectors, dock=(3, 19))


# ---------------------------------------------------------------------------
# Sensor physics: ONE function generates readings for training AND live sim,
# so the classifier sees the same kind of signal in both.
# ---------------------------------------------------------------------------
CHANNELS = ["CO_ppm", "CO2_ppm", "CH4_ppm", "H2_ppm", "VOC_ppb",
            "NO2_ppb", "PM25_ugm3", "TEMP_C", "HUM_pct", "FLAME"]
BASELINE = np.array([1.0, 450.0, 5.0, 1.0, 50.0, 10.0, 10.0, 23.0, 45.0, 0.0])


def sensor_sample(kind: str, i: float, rng, flame_visible=True, nuisance_type=0):
    """One reading of the 10-channel detector for an event of `kind` at local intensity i (0..1)."""
    x = BASELINE.copy()
    if kind == "gas_leak":
        x[2] += 20000 * i; x[3] += 40 * i; x[4] += 120 * i
    elif kind == "smouldering":
        x[0] += 300 * i; x[1] += 600 * i; x[4] += 800 * i; x[6] += 400 * i; x[7] += 8 * i
    elif kind == "flaming":
        x[0] += 120 * i; x[1] += 4000 * i; x[5] += 300 * i; x[6] += 600 * i
        x[7] += 60 * i; x[8] -= 10 * i
        x[9] = i if (flame_visible and i > 0.25) else 0.0
    elif kind == "nuisance":
        if nuisance_type == 0:        # steam (shower, kettle)
            x[8] += 40 * i; x[6] += 150 * i; x[7] += 3 * i
        else:                         # cooking fumes
            x[4] += 600 * i; x[6] += 250 * i; x[1] += 300 * i; x[7] += 4 * i
    noise = rng.normal(0, 0.04, size=x.shape) * np.maximum(x, 1.0) + rng.normal(0, 0.5, size=x.shape)
    noise[9] = 0.0
    return np.maximum(x + noise, 0.0)


def local_intensity(building: Building, event: Event, pos) -> float:
    """How strongly a sensor at `pos` feels the event: decays with distance, walls reduce it."""
    if event.extinguished and event.kind != "gas_leak":
        return 0.0
    d_m = math.dist(pos, event.pos) * CELL_M
    same_room = building.room_at(*pos) == building.room_at(*event.pos)
    wall = 1.0 if same_room else 0.35
    return float(event.intensity * wall * math.exp(-d_m / 7.0))
