"""
The AI box: mission manager that ties Model 1 and Model 2 together
(Algorithm "AIBox_Mission" in the doc).

MONITOR -> ASSESS -> ALERT -> DISPATCH -> CONFIRM -> ACT -> SEARCH -> REPORT -> CLOSE

`call_firefighters` and the building actions (alarm, cut gas, ventilate) only
log here. On the real system they must go through a certified fire-alarm
panel / emergency-call interface, never only through this software.
"""
from __future__ import annotations

import math

import numpy as np

from common.building import CELL_M, line_of_sight, local_intensity, sensor_sample
from model1_navigation.navigator import DroneNavigator
from model1_navigation.perception import SimPerception
from model2_detection.fusion import (DetectorNode, FusionEngine, decide, fire_level,
                                     update_with_drone)


class AIBox:
    def __init__(self, building, classifier, event=None, occupancy=None, seed=0, verbose=True):
        self.b = building
        self.event = event
        self.rng = np.random.default_rng(seed)
        self.nodes = [DetectorNode(d, classifier) for d in building.detectors]
        self.fusion = FusionEngine(building, occupancy)
        self.drone = DroneNavigator(building, SimPerception(building, seed=seed), log=self.log)
        self.t = 0.0
        self.sub = 0.0
        self.situation = None
        self.firefighters_called = False
        self.actions_done = set()
        self.verbose = verbose
        self.lines = []

    # ---------------- utilities ----------------
    def log(self, msg):
        line = f"t={self.t:6.1f}s  {msg}"
        self.lines.append(line)
        if self.verbose:
            print(line)

    def tick_detectors(self):
        """1 second of the world: the event evolves, every detector takes a reading."""
        if self.event:
            self.event.step(1.0)
        alerts = []
        for n in self.nodes:
            if self.event:
                i = local_intensity(self.b, self.event, n.d.pos)
                visible = line_of_sight(self.b.true_grid, n.d.pos, self.event.pos)
                r = sensor_sample(self.event.kind, i, self.rng, flame_visible=visible)
            else:
                r = sensor_sample("normal", 0.0, self.rng)
            a = n.push(r)
            if a:
                alerts.append(a)
        self.t += 1.0
        return alerts

    def advance(self, dt):
        """Advance the clock by dt while the drone flies (detectors keep running at 1 Hz)."""
        self.sub += dt
        alerts = []
        while self.sub >= 1.0:
            self.sub -= 1.0
            alerts = self.tick_detectors()
        return alerts

    def thermal_reading(self):
        e = self.event
        if (e and not e.extinguished and math.dist(self.drone.pose, e.pos) < 20
                and line_of_sight(self.b.true_grid, self.drone.pose, e.pos)):
            out = {"hot_area_m2": e.hot_area_m2, "t_max_c": e.t_max_c}
        else:
            out = {"hot_area_m2": 0.0, "t_max_c": 25.0}
        if e and e.kind == "gas_leak":                    # drone gas array
            out["gas_level"] = local_intensity(self.b, e, self.drone.pose)
        return out

    def call_firefighters(self, reason):
        if self.firefighters_called:
            return
        self.firefighters_called = True
        s = self.situation
        self.log(f"*** CALLING FIREFIGHTERS ({reason}) ***")
        self.log("    report: " + str(self.report()))

    def report(self):
        s = self.situation
        return {"room": s.room, "source_m": (round(s.source[0] * CELL_M, 1), round(s.source[1] * CELL_M, 1)),
                "event": s.event, "level": s.level, "fire_class": s.fire_class, "gas": s.gas,
                "hot_area_m2": round(s.hot_area_m2, 1), "t_max_c": round(s.t_max_c),
                "survivors_m": [(round(x * CELL_M, 1), round(y * CELL_M, 1)) for x, y in s.survivors],
                "blocked_doors": [k for k, v in self.drone.graph.edges.items() if v["blocked"]]}

    def run_actions(self, actions):
        for a in actions:
            if a == "CALL_FIREFIGHTERS":
                self.call_firefighters(f"level {self.situation.level}")
            elif a == "release_co2":
                continue                                   # handled by the on-site loop
            elif a not in self.actions_done:
                self.actions_done.add(a)
                self.log(f"action: {a}")
                if a.startswith(("cut_gas", "ventilate")) and self.event and self.event.kind == "gas_leak":
                    self.event.growth = -0.01             # leak stops and the gas clears

    # ---------------- the mission ----------------
    def run(self, warmup_s=60, event_start_s=10, max_s=600):
        live_event, self.event = self.event, None
        self.log("MONITOR: detectors warming up (filling 60 s windows)")
        for _ in range(warmup_s):
            self.tick_detectors()
        for _ in range(event_start_s):
            self.tick_detectors()
        self.event = live_event
        self.log(f"(simulation) hidden event starts: {self.event.kind} in {self.b.room_at(*self.event.pos)}")

        # 1-2. MONITOR + ASSESS
        while self.t < max_s:
            alerts = self.tick_detectors()
            if not alerts:
                continue
            s = self.fusion.assess(alerts)
            if s.risk < 30:
                self.log(f"low-risk signal in {s.room} ({s.event}, risk {s.risk:.0f}) - logged")
                continue
            self.situation = s
            break
        else:
            self.log("no dangerous event detected")
            return self.summary()

        s = self.situation
        det_list = ", ".join(sorted({f"{a.det_id}:{a.label}" for a in alerts}))
        self.log(f"ASSESS: {s.event} in {s.room}, risk {s.risk:.0f}/100, gas={s.gas}, "
                 f"class={s.fire_class}, CO2 ok={s.co2_ok}  [{det_list}]")

        # 3. ALERT
        self.run_actions([f"alarm:{s.room}", "notify:security"])
        if s.risk >= 90 and s.event == "flaming":
            self.call_firefighters("sensors alone show a severe fire")

        # 4. DISPATCH (Model 1 flies, Model 2 keeps updating)
        self.log(f"DISPATCH: {self.drone.id} -> {s.room}")
        self.fly_to(s.source, stop_dist=6, need_los=True)
        if s.event != "gas_leak" and not s.source_seen:
            self.search_room_for_fire(s.room)
        if s.source_seen:
            sp = self.drone.standoff_point(s.source)
            self.fly_to(sp, stop_dist=1.0)
        self.log(f"ON SITE at ({self.drone.pose[0] * CELL_M:.1f} m, {self.drone.pose[1] * CELL_M:.1f} m), "
                 f"source located by camera={s.source_seen}")

        # 5-6. CONFIRM + ACT
        attempts, calm, prev_level = 0, 0, None
        for _ in range(120):
            update_with_drone(s, self.drone.perception.detect(tuple(self.drone.pose), self.event),
                              self.thermal_reading(), dt=1.0)
            s.level = fire_level(s)
            if s.event != "gas_leak" and not s.source_seen:
                s.level = max(s.level, 3)                  # sensors say fire but the drone cannot find it
                self.log("CONFIRM: fire detected by sensors but not located by the drone")
            if s.level != prev_level:
                self.log(f"CONFIRM: level {s.level}  (hot area {s.hot_area_m2:.1f} m2, "
                         f"T max {s.t_max_c:.0f} C, people in room={s.people_in_room})")
                prev_level = s.level
            actions = decide(s, self.drone.co2_bombs, attempts)
            self.run_actions(actions)
            if "release_co2" in actions:
                self.drone.co2_bombs -= 1
                attempts += 1
                self.event.hit_with_co2()
                self.log(f"ACT: CO2 bomb released ({self.drone.co2_bombs} left)")
                self.advance(5.0)                          # wait and watch
                continue
            if s.level >= 3 or self.firefighters_called and s.level >= 2:
                break                                     # firefighters take over the fire
            calm = calm + 1 if s.level == 0 else 0
            if calm >= 10:
                self.log("ACT: situation clear for 10 s (no flame, no heat" +
                         (", gas cleared)" if s.event == "gas_leak" else ")"))
                break
            self.advance(1.0)

        # 7. SEARCH for survivors around the fire
        for room in self.drone.graph.search_order(s.room)[:3]:
            if self.drone.battery < 0.35:
                break
            target = self.b.room(room).center
            self.log(f"SEARCH: sweeping {room}")
            self.fly_to(target, stop_dist=3)
        if s.survivors:
            self.log(f"SEARCH: {len(s.survivors)} survivor(s) found")
            self.call_firefighters("survivors found")

        # 8-9. REPORT + CLOSE
        self.log("REPORT: " + str(self.report()))
        self.log(f"RETURN: {self.drone.id} to dock")
        self.fly_to(self.b.dock, stop_dist=1.0)
        self.log(f"CLOSE: battery {self.drone.battery:.0%}, CO2 left {self.drone.co2_bombs}, "
                 f"firefighters called={self.firefighters_called}")
        return self.summary()

    def search_room_for_fire(self, room):
        """The fire is hidden (furniture, smoke): visit points around the room until the drone sees it."""
        r = self.b.room(room)
        pts = [(r.x0 + 3, r.y0 + 3), (r.x1 - 3, r.y0 + 3), (r.x1 - 3, r.y1 - 3), (r.x0 + 3, r.y1 - 3), r.center]
        pts.sort(key=lambda p: math.dist(p, self.drone.pose))
        self.log(f"CONFIRM: fire not visible yet - searching {room}")
        for p in pts:
            self.fly_to(self.drone.nearest_free(p), stop_dist=1.5, until_seen=True)
            if self.situation.source_seen:
                return True
        return False

    def fly_to(self, goal, stop_dist, need_los=False, until_seen=False):
        s = self.situation

        def on_step(drone, dets):
            self.advance(0.5)
            if s:
                before = len(s.survivors)
                update_with_drone(s, dets, self.thermal_reading(), dt=0.5)
                if len(s.survivors) > before:
                    self.log(f"SURVIVOR spotted in {self.b.room_at(*s.survivors[-1])}")
                return until_seen and s.source_seen
            return False
        return self.drone.go_to(goal, self.event, stop_dist=stop_dist, need_los=need_los, on_step=on_step)

    def summary(self):
        s = self.situation
        return {"detected": s is not None, "level": s.level if s else 0,
                "firefighters_called": self.firefighters_called,
                "extinguished": bool(self.event and self.event.extinguished),
                "co2_used": 3 - self.drone.co2_bombs, "survivors": len(s.survivors) if s else 0,
                "time_s": self.t}
