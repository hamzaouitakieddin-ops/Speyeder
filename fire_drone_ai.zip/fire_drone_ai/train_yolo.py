"""
Train the drone's vision model (Model 1 perception) - transfer learning on YOLOv8n.

1. Collect images (public fire/smoke datasets + your own drone footage, RGB and thermal).
2. Label them in YOLO format (Roboflow, CVAT or Label Studio) with the classes in data/fire_drone.yaml.
3. Put them in datasets/fire_drone/{images,labels}/{train,val,test}
4. Run:   pip install ultralytics
          python train_yolo.py
5. Copy the exported engine to the Jetson and load it with YoloPerception.
"""
from ultralytics import YOLO


def main():
    model = YOLO("yolov8n.pt")                 # backbone pre-trained on COCO (transfer learning)
    model.train(
        data="data/fire_drone.yaml",
        epochs=100,
        imgsz=640,
        batch=16,
        patience=20,                           # early stopping (workshop: stop at the validation minimum)
        hsv_v=0.5, degrees=10, fliplr=0.5,     # augmentation: lighting, drone tilt
        project="weights", name="fire_drone_yolov8n",
    )
    metrics = model.val(split="test")          # mAP50 / mAP50-95 on the held-out test split
    print("test mAP50:", metrics.box.map50)
    # Edge deployment on the Jetson: TensorRT, INT8 (calibrated on the val images)
    model.export(format="engine", int8=True, data="data/fire_drone.yaml")
    # Or a portable version:  model.export(format="onnx")


if __name__ == "__main__":
    main()
