"""
Model 2 - Layers A (runtime), B and C: from detector readings to a decision.

DetectorNode   : runs inside each fixed detector (Layer A): rolling buffer,
                 classifier, hard alarms -> an Alert for the box.
FusionEngine   : runs in the AI box (Layer B): locate the source, analyse the
                 gas composition, compute a 0-100 risk score.
update_with_drone : Layer C - the drone's thermal camera + gas array refine the
                 estimate (source position and fire size).
fire_level     : 0..4 (the table in the doc).
decide         : which actions to take (CO2, utilities, call firefighters...).

All numeric thresholds are STARTING VALUES marked CALIBRATE: tune them with
real tests and validate them with a fire-safety engineer.
"""
from __future__ import annotations

import math
from collections import deque
from dataclasses import dataclass, field

import numpy as np

from common.building import CHANNELS
from model2_detection.detector_model import CLASSES, WINDOW
from model2_detection.preprocess import hard_alarms, normalise

FIRE_IDX = [CLASSES.index("smouldering"), CLASSES.index("flaming")]
LEAK_IDX = CLASSES.index("gas_leak")


# ---------------------------------------------------------------------------
# Layer A - inside each detector
# ---------------------------------------------------------------------------
@dataclass
class Alert:
    det_id: str
    pos: tuple
    room: str
    probs: np.ndarray
    label: str
    hard: list
    last: np.ndarray            # latest raw reading
    rise: float                 # how far above normal the window is (0..~3)

    @property
    def p_event(self):
        return float(1.0 - self.probs[0] - self.probs[CLASSES.index("nuisance")])


class DetectorNode:
    def __init__(self, detector, classifier):
        self.d = detector
        self.clf = classifier
        self.buf = deque(maxlen=WINDOW)

    def push(self, reading) -> Alert | None:
        self.buf.append(reading)
        if len(self.buf) < WINDOW:
            return None
        window = np.stack(self.buf)
        probs = self.clf.predict_proba(window)
        hard = hard_alarms(window)
        label = CLASSES[int(probs.argmax())]
        z = normalise(window)
        rise = float(np.clip(z[:9, -5:].mean(1), 0, None).max())
        if label in ("normal", "nuisance") and not hard:
            return None                         # nothing to report (the box still gets heartbeats)
        return Alert(self.d.det_id, self.d.pos, self.d.room, probs, label, hard, window[-1], rise)


# ---------------------------------------------------------------------------
# Layer B - fusion in the AI box
# ---------------------------------------------------------------------------
@dataclass
class Situation:
    event: str = "none"                 # gas_leak | smouldering | flaming
    room: str = "?"
    source: tuple = (0.0, 0.0)
    risk: float = 0.0
    gas: str = "-"
    fire_class: str = "-"
    co2_ok: str = "-"                   # yes | partial | no
    people_in_room: bool = False
    survivors: list = field(default_factory=list)
    hot_area_m2: float = 0.0
    t_max_c: float = 25.0
    growth_m2_s: float = 0.0
    fire_seen: bool = False             # flames visible right now
    source_seen: bool = False           # the drone has located the fire / smoke at least once
    gas_level: float = 1.0              # drone gas array, 0..1 of the leak strength
    level: int = 0
    history: list = field(default_factory=list)


class FusionEngine:
    def __init__(self, building, occupancy=None):
        self.b = building
        self.occupancy = occupancy or {}           # room -> people expected (from access control / schedule)

    def locate_source(self, alerts):
        """Weighted centroid of the strongest detectors, snapped to the strongest room."""
        alerts = sorted(alerts, key=lambda a: a.p_event * (1 + a.rise), reverse=True)
        top = alerts[0]
        same = [a for a in alerts if a.room == top.room] or [top]
        w = np.array([(a.p_event * (1 + a.rise)) ** 2 for a in same])
        pos = np.array([a.pos for a in same], dtype=float)
        c = (w[:, None] * pos).sum(0) / w.sum()
        return top.room, (float(c[0]), float(c[1]))

    def composition(self, alerts, room):
        """Which gas, which fire class, does CO2 work on it."""
        a = max(alerts, key=lambda x: x.p_event)
        r = dict(zip(CHANNELS, a.last))
        p = a.probs
        event = ["gas_leak", "smouldering", "flaming"][int(np.argmax([p[LEAK_IDX], p[FIRE_IDX[0]], p[FIRE_IDX[1]]]))]
        flammable = r["CH4_ppm"] > 500 or r["H2_ppm"] > 400
        gas = ("CH4 (natural gas)" if r["CH4_ppm"] > 500 else
               "H2" if r["H2_ppm"] > 400 else
               "CO (combustion)" if r["CO_ppm"] > 30 else
               "smoke / VOC" if r["VOC_ppb"] > 400 else "unclear")
        tags = self.b.room(room).tags if room in [x.name for x in self.b.rooms] else ()
        if event == "gas_leak":
            fire_class, co2 = "no fire (leak)", "no"
        elif "electrical" in tags:
            fire_class, co2 = "electrical", "yes"
        elif flammable:
            fire_class, co2 = "C - gas fire", "no"           # never put out a gas fire while gas still flows
        elif "chemicals" in tags or r["VOC_ppb"] > 3 * r["PM25_ugm3"]:
            fire_class, co2 = "B - liquids", "yes"
        else:
            fire_class, co2 = "A - solids", "partial"        # CO2 only knocks down surface flames
        return event, gas, fire_class, co2

    def risk_score(self, alerts, event, room):
        p = max(a.p_event for a in alerts)
        rise = max(a.rise for a in alerts)
        agree = len({a.det_id for a in alerts if a.p_event > 0.5})
        hard = any(a.hard for a in alerts)
        score = 45 * p + 15 * min(rise / 2, 1) + 10 * min(agree / 3, 1) + (20 if hard else 0)
        if event == "flaming":
            score += 10
        if self.occupancy.get(room, 0) > 0:
            score += 10
        return float(min(100.0, score))

    def assess(self, alerts) -> Situation:
        room, src = self.locate_source(alerts)
        event, gas, fclass, co2 = self.composition(alerts, room)
        s = Situation(event=event, room=room, source=src, gas=gas, fire_class=fclass, co2_ok=co2)
        s.risk = self.risk_score(alerts, event, room)
        s.people_in_room = self.occupancy.get(room, 0) > 0
        return s


# ---------------------------------------------------------------------------
# Layer C - drone confirmation
# ---------------------------------------------------------------------------
def update_with_drone(s: Situation, dets, thermal, dt):
    """dets: drone YOLO detections; thermal: dict(hot_area_m2, t_max_c) from the thermal camera."""
    fire = [d for d in dets if d["cls"] in ("fire", "smoke") and d.get("room") == s.room]
    if fire:
        k = 0.8                                            # trust the drone's eyes more than the room sensors
        fx, fy = fire[0]["pos"]
        s.source = (s.source[0] + k * (fx - s.source[0]), s.source[1] + k * (fy - s.source[1]))
        s.source_seen = True
    s.fire_seen = any(d["cls"] == "fire" for d in fire)    # what the drone sees NOW
    prev = s.hot_area_m2
    s.hot_area_m2 = thermal["hot_area_m2"]
    s.t_max_c = thermal["t_max_c"]
    s.gas_level = thermal.get("gas_level", s.gas_level)
    s.growth_m2_s = (s.hot_area_m2 - prev) / dt if prev else 0.0
    for d in dets:
        if d["cls"] == "person":
            if all(math.dist(d["pos"], p) > 2 for p in s.survivors):
                s.survivors.append(d["pos"])
            if d.get("room") == s.room:
                s.people_in_room = True
    return s


# ---------------------------------------------------------------------------
# Fire level + decision
# ---------------------------------------------------------------------------
def fire_level(s: Situation) -> int:
    """0..4 - CALIBRATE every threshold with real burn tests."""
    if s.event == "gas_leak":
        if s.fire_seen:
            return 4                                      # leak + flame = explosion risk
        return 1 if s.gas_level > 0.03 else 0
    if s.people_in_room and (s.fire_seen or s.t_max_c > 60):
        return 4
    if s.hot_area_m2 > 15 or s.t_max_c > 500:
        return 4
    if s.hot_area_m2 > 4 or s.growth_m2_s > 0.15 or (s.fire_seen and s.co2_ok == "no"):
        return 3
    if s.fire_seen or s.t_max_c > 60:
        return 2
    if s.event == "smouldering" and s.risk > 40:
        return 1
    return 0


def decide(s: Situation, drone_co2_left: int, attempts: int, max_attempts=2) -> list[str]:
    a = ["alarm:" + s.room]
    if s.level >= 1 and s.event == "gas_leak":
        a += ["cut_gas:" + s.room, "cut_power:" + s.room, "ventilate:" + s.room, "no_co2:ignition_risk"]
    if s.level >= 4 or s.survivors:
        a += ["CALL_FIREFIGHTERS", "evacuate:building", "drone:scout_and_guide"]
    elif s.level == 3:
        a += ["CALL_FIREFIGHTERS", "drone:contain_if_safe"]
    elif s.level == 2:
        a.append("prealert_firefighters")
        if s.people_in_room:
            a += ["CALL_FIREFIGHTERS", "no_co2:people_in_room"]
        elif s.co2_ok == "no":
            a.append("CALL_FIREFIGHTERS")
        elif drone_co2_left == 0 or attempts >= max_attempts:
            a.append("CALL_FIREFIGHTERS")
        else:
            a.append("release_co2")
    return a
