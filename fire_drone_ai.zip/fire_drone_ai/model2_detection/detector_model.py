"""
Model 2 - Layer A, step 3: the classifier inside each fixed detector.

Classes: 0 normal | 1 gas_leak | 2 smouldering | 3 flaming | 4 nuisance

GasCNN          : the real model (PyTorch 1D-CNN, ~10k parameters). Train it,
                  export to ONNX, quantize to INT8 and flash it on the MCU
                  (STM32Cube.AI or TFLite Micro), as in the workshop.
DetectorClassifier: one interface for the whole system. It uses the PyTorch
                  model when torch is installed, otherwise a small scikit-learn
                  MLP on hand-made features (so the simulator runs anywhere).
make_dataset    : synthetic training windows from the same sensor physics as
                  the simulator. Replace / extend with your lab recordings.
"""
from __future__ import annotations

import pickle

import numpy as np

from common.building import sensor_sample
from model2_detection.preprocess import flat_features, normalise

CLASSES = ["normal", "gas_leak", "smouldering", "flaming", "nuisance"]
KIND_OF_CLASS = {1: "gas_leak", 2: "smouldering", 3: "flaming", 4: "nuisance"}
WINDOW = 60          # 60 readings = 60 s at 1 Hz

try:
    import torch
    import torch.nn as nn
    HAS_TORCH = True
except ImportError:
    HAS_TORCH = False


# ---------------------------------------------------------------------------
# Data
# ---------------------------------------------------------------------------
def make_window(cls: int, rng, T=WINDOW):
    """One labelled window: the event starts at a random time and ramps up."""
    if cls == 0:
        return np.stack([sensor_sample("normal", 0.0, rng) for _ in range(T)])
    kind = KIND_OF_CLASS[cls]
    peak = rng.uniform(0.15, 1.0)
    start = int(rng.integers(0, T // 2))
    ramp = rng.uniform(5, 40)                       # seconds to reach the peak
    nuis = int(rng.integers(0, 2))
    flame_vis = rng.random() < 0.6
    rows = []
    for t in range(T):
        i = 0.0 if t < start else peak * min(1.0, (t - start) / ramp)
        rows.append(sensor_sample(kind, i, rng, flame_visible=flame_vis, nuisance_type=nuis))
    return np.stack(rows)


def make_dataset(n_per_class=600, seed=0):
    rng = np.random.default_rng(seed)
    X, y = [], []
    for c in range(len(CLASSES)):
        for _ in range(n_per_class):
            X.append(make_window(c, rng))
            y.append(c)
    return np.stack(X), np.array(y)


# ---------------------------------------------------------------------------
# PyTorch model (the one deployed on the detectors)
# ---------------------------------------------------------------------------
if HAS_TORCH:
    class GasCNN(nn.Module):
        def __init__(self, n_channels=10, n_classes=5):
            super().__init__()
            self.net = nn.Sequential(
                nn.Conv1d(n_channels, 16, 5, padding=2), nn.ReLU(), nn.MaxPool1d(2),
                nn.Conv1d(16, 32, 5, padding=2), nn.ReLU(), nn.MaxPool1d(2),
                nn.Conv1d(32, 32, 3, padding=1), nn.ReLU(),
                nn.AdaptiveAvgPool1d(1), nn.Flatten(),
                nn.Linear(32, n_classes),
            )

        def forward(self, x):          # x: (N, 10, T)
            return self.net(x)

    def train_cnn(Xn, y, Xv, yv, epochs=25, lr=1e-3, batch=64, device="cpu"):
        model = GasCNN().to(device)
        opt = torch.optim.Adam(model.parameters(), lr=lr)
        loss_fn = nn.CrossEntropyLoss()
        ds = torch.utils.data.TensorDataset(torch.tensor(Xn), torch.tensor(y))
        loader = torch.utils.data.DataLoader(ds, batch_size=batch, shuffle=True)
        xv, yv_t = torch.tensor(Xv).to(device), torch.tensor(yv).to(device)
        best, best_state = 0.0, None
        for ep in range(epochs):
            model.train()
            for xb, yb in loader:
                xb, yb = xb.to(device), yb.to(device)
                logits = model(xb)              # forward
                loss = loss_fn(logits, yb)      # loss
                opt.zero_grad()
                loss.backward()                 # backward
                opt.step()                      # step
            model.eval()
            with torch.no_grad():
                acc = (model(xv).argmax(1) == yv_t).float().mean().item()
            if acc >= best:                      # early stopping on validation
                best, best_state = acc, {k: v.clone() for k, v in model.state_dict().items()}
            print(f"epoch {ep + 1:2d}  loss {loss.item():.3f}  val acc {acc:.3f}")
        model.load_state_dict(best_state)
        return model.cpu()

    def export_onnx(model, path="weights/gas_cnn.onnx"):
        """Next steps for the MCU: ONNX -> INT8 quantization -> STM32Cube.AI / TFLite Micro -> C array."""
        model.eval()
        torch.onnx.export(model, torch.randn(1, 10, WINDOW), path, opset_version=13,
                          input_names=["window"], output_names=["logits"])
        return path


# ---------------------------------------------------------------------------
# One interface used by the AI box and the simulator
# ---------------------------------------------------------------------------
class DetectorClassifier:
    def __init__(self, backend=None):
        self.backend = backend or ("torch" if HAS_TORCH else "sklearn")
        self.model = None

    def fit(self, X, y, Xv=None, yv=None):
        if self.backend == "torch":
            Xn = np.stack([normalise(w) for w in X])
            Xvn = np.stack([normalise(w) for w in Xv]) if Xv is not None else Xn
            self.model = train_cnn(Xn, y, Xvn, yv if yv is not None else y)
        else:
            from sklearn.neural_network import MLPClassifier
            from sklearn.pipeline import make_pipeline
            from sklearn.preprocessing import StandardScaler
            F = np.stack([flat_features(w) for w in X])
            self.model = make_pipeline(StandardScaler(),
                                       MLPClassifier((64, 32), max_iter=600, early_stopping=True, random_state=0))
            self.model.fit(F, y)
        return self

    def predict_proba(self, window: np.ndarray) -> np.ndarray:
        """window: (T, 10) raw readings -> probabilities for the 5 classes."""
        if self.backend == "torch":
            with torch.no_grad():
                logits = self.model(torch.tensor(normalise(window))[None])
                return torch.softmax(logits, 1).numpy()[0]
        return self.model.predict_proba(flat_features(window)[None])[0]

    def predict_many(self, X):
        return np.array([self.predict_proba(w).argmax() for w in X])

    def save(self, path):
        if self.backend == "torch":
            torch.save(self.model.state_dict(), path)
        else:
            with open(path, "wb") as f:
                pickle.dump(self.model, f)

    def load(self, path):
        if self.backend == "torch":
            self.model = GasCNN()
            self.model.load_state_dict(torch.load(path, map_location="cpu"))
            self.model.eval()
        else:
            with open(path, "rb") as f:
                self.model = pickle.load(f)
        return self
