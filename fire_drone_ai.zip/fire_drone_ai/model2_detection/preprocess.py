"""
Model 2 - Layer A, step 1-2: signal cleaning + features (runs inside each detector).

Input : a window of raw readings, shape (T, 10) - see common.building.CHANNELS
Output: normalised window (10, T) for the 1D-CNN, or a flat feature vector
        (last, mean, max, slope per channel) for the light fallback model.
Also  : hard safety thresholds that alarm WITHOUT the AI.
"""
from __future__ import annotations

import numpy as np

from common.building import BASELINE, CHANNELS

# divide each channel's rise above baseline by this before the log
SCALE = np.array([100, 1000, 5000, 50, 300, 100, 200, 20, 20, 1], dtype=np.float32)

# Hard alarm limits - CALIBRATE with your sensor datasheets and local fire code.
# CH4: lower explosive limit (LEL) = 5 % vol = 50 000 ppm; alarm at 10 % LEL.
HARD_LIMITS = {
    "CO_ppm": 50.0,          # CO alarm level used by many detectors
    "CH4_ppm": 5000.0,       # 10 % of LEL
    "H2_ppm": 4000.0,        # 10 % of LEL (H2 LEL = 4 % vol)
    "TEMP_C": 57.0,          # fixed-temperature heat detector rating
    "FLAME": 0.5,
}


def moving_average(window: np.ndarray, k=3) -> np.ndarray:
    kernel = np.ones(k) / k
    out = np.empty_like(window, dtype=np.float32)
    for c in range(window.shape[1]):
        out[:, c] = np.convolve(np.pad(window[:, c], (k - 1, 0), mode="edge"), kernel, mode="valid")
    return out


def normalise(window: np.ndarray) -> np.ndarray:
    """(T, 10) raw -> (10, T) float32 for the CNN. Signed log keeps big gas peaks in range."""
    w = moving_average(window)
    z = (w - BASELINE) / SCALE
    z = np.sign(z) * np.log1p(np.abs(z))
    return z.T.astype(np.float32)


def flat_features(window: np.ndarray) -> np.ndarray:
    """40 features for the fallback model / gradient boosting."""
    z = normalise(window)                     # (10, T)
    t = z.shape[1]
    slope = (z[:, -5:].mean(1) - z[:, :5].mean(1)) / t
    return np.concatenate([z[:, -1], z.mean(1), z.max(1), slope * 100]).astype(np.float32)


def hard_alarms(window: np.ndarray) -> list[str]:
    """Rule-based alarms on the latest reading. These never depend on the AI."""
    last = window[-1]
    return [name for name, lim in HARD_LIMITS.items() if last[CHANNELS.index(name)] >= lim]
