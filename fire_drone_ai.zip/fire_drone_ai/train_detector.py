"""
Train + evaluate the Layer A detector classifier (Model 2).

    python train_detector.py              # uses PyTorch if installed, else scikit-learn
    python train_detector.py --backend sklearn

Prints the workshop's evaluation criteria: macro-F1, confusion matrix,
recall on the dangerous classes, latency and model size.
"""
import argparse
import os
import time

import numpy as np
from sklearn.metrics import classification_report, confusion_matrix, f1_score
from sklearn.model_selection import train_test_split

from model2_detection.detector_model import CLASSES, HAS_TORCH, DetectorClassifier, make_dataset


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--backend", choices=["torch", "sklearn"], default=None)
    ap.add_argument("--n", type=int, default=600, help="windows per class")
    args = ap.parse_args()
    os.makedirs("weights", exist_ok=True)

    print("Generating synthetic sensor windows ...")
    X, y = make_dataset(args.n, seed=0)
    Xtr, Xte, ytr, yte = train_test_split(X, y, test_size=0.2, stratify=y, random_state=0)
    Xtr, Xva, ytr, yva = train_test_split(Xtr, ytr, test_size=0.15, stratify=ytr, random_state=0)

    clf = DetectorClassifier(args.backend)
    print(f"Training backend: {clf.backend}")
    clf.fit(Xtr, ytr, Xva, yva)

    t0 = time.time()
    pred = clf.predict_many(Xte)
    ms = (time.time() - t0) / len(Xte) * 1000

    print("\n=== Evaluation on held-out test set ===")
    print(f"Macro-F1: {f1_score(yte, pred, average='macro'):.3f}")
    print(classification_report(yte, pred, target_names=CLASSES, digits=3))
    print("Confusion matrix (rows = true, cols = predicted):")
    print("            " + " ".join(f"{c[:8]:>9}" for c in CLASSES))
    for c, row in zip(CLASSES, confusion_matrix(yte, pred)):
        print(f"{c[:11]:>11} " + " ".join(f"{v:9d}" for v in row))
    danger = np.isin(yte, [1, 2, 3])
    missed = np.mean(np.isin(pred[danger], [0, 4]))
    print(f"\nMissed dangers (leak/fire predicted as normal/nuisance): {missed:.1%}  <- the costly error")
    print(f"Latency: {ms:.2f} ms per window on this machine")

    path = "weights/gas_detector." + ("pt" if clf.backend == "torch" else "pkl")
    clf.save(path)
    print(f"Saved {path} ({os.path.getsize(path) / 1024:.1f} KB)")
    if clf.backend == "torch":
        from model2_detection.detector_model import export_onnx
        print("Exported", export_onnx(clf.model), "-> next: INT8 quantization + STM32Cube.AI / TFLite Micro")
    elif not HAS_TORCH:
        print("Tip: pip install torch, then re-run to train the 1D-CNN that goes on the detectors.")


if __name__ == "__main__":
    main()
